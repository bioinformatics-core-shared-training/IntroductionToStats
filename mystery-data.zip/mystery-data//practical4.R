myfile <- "data4.csv"
sep <- ','
quote <- '"'
header <-  TRUE 
skip <-  0 
data <- read.csv(myfile, header=header, sep=sep, quote=quote,skip=skip)
data <- reshape2::melt(data)
colnames(data) <- c('variable','value')
head(data)
library(ggplot2)
p <- ggplot(data, aes(x = variable,y=value,fill=variable)) + geom_boxplot() + coord_flip()
p
lapply(split(data$value,data$variable),summary)
p <- ggplot(data, aes(x=value)) + geom_histogram(aes(y=..density..),colour='black',fill='white') + facet_wrap(~variable) + stat_function(fun=dnorm,color='red',arg=list(mean=mean(data$value), sd=sd(data$value)))
var.test(value~variable,data=data)
p
alternative <- 'two.sided'
paired <- FALSE
var.equal <-TRUE
t.test(value~variable,data=data,alternative=alternative,paired=paired,var.equal=var.equal)
